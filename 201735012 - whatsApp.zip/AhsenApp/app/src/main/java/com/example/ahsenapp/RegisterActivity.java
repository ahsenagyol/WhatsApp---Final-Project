package com.example.ahsenapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private Button RegisterCreateButton;
    private EditText UserMail, UserPassword;
    private TextView AlreadyAnAccount;

    //Firebase
    private DatabaseReference kokReference;
    private FirebaseAuth mAuthority;

    private ProgressDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        //Firebase Definitions
        mAuthority=FirebaseAuth.getInstance();
        kokReference= FirebaseDatabase.getInstance().getReference();

        //Control Definitions
        RegisterCreateButton=findViewById(R.id.register_button);

        UserMail=findViewById(R.id.register_email);
        UserPassword=findViewById(R.id.register_password);

        AlreadyAnAccount = findViewById(R.id.an_account);

        loadingDialog=new ProgressDialog(this);


        AlreadyAnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginActivityIntent = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(LoginActivityIntent);
            }
        });

        RegisterCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CreateNewAccount();
            }
        });
    }

    private void CreateNewAccount()
    {
        String email = UserMail.getText().toString();
        String password = UserPassword.getText().toString();

        if (TextUtils.isEmpty(email))
        {
            Toast.makeText(this, "Email cannot be empty...", Toast.LENGTH_SHORT).show();
        }

        if (TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Password cannot be empty...", Toast.LENGTH_SHORT).show();
        }

        else
            {

                loadingDialog.setTitle("Creating New Account");
                loadingDialog.setMessage("Please Wait...");
                loadingDialog.setCanceledOnTouchOutside(true);
                loadingDialog.show();


                mAuthority.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {

                                if (task.isSuccessful())
                                {

                                    String currentUserId=mAuthority.getCurrentUser().getUid();
                                    kokReference.child("Users").child(currentUserId).setValue("");


                                    Intent mainPage=new Intent(RegisterActivity.this,MainActivity.class);
                                    mainPage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(mainPage);
                                    finish();

                                    Toast.makeText(RegisterActivity.this, "New account successfully created...", Toast.LENGTH_SHORT).show();
                                    loadingDialog.dismiss();
                                }

                                else
                                    {
                                        String message=task.getException().toString();
                                        Toast.makeText(RegisterActivity.this, "Error: "+ message+" Check your information!", Toast.LENGTH_SHORT).show();
                                        loadingDialog.dismiss();
                                    }
                            }
                        });


            }



    }
}
package com.example.ahsenapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity<Toolbar> extends AppCompatActivity {

    private Toolbar mToolbar;
    private ViewPager myViewPager;
    private TabLayout myTabLayout;
    private TabAccessAdapter mytabAccessAdapter;

    //Firebase
    private FirebaseUser currentUser;
    private FirebaseAuth mAuthority;
    private DatabaseReference usersReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToolbar= (Toolbar) findViewById(R.id.main_page_toolbar);
        setSupportActionBar((androidx.appcompat.widget.Toolbar) mToolbar);
        getSupportActionBar().setTitle("WhatsApp");

        myViewPager=findViewById(R.id.main_tabs_pager);
        mytabAccessAdapter=new TabAccessAdapter(getSupportFragmentManager());
        myViewPager.setAdapter(mytabAccessAdapter);

        myTabLayout=findViewById(R.id.main_tabs);
        myTabLayout.setupWithViewPager(myViewPager);

        //Firebase
        mAuthority=FirebaseAuth.getInstance();
        currentUser=mAuthority.getCurrentUser();
        usersReference= FirebaseDatabase.getInstance().getReference();

    }

    @Override
    protected void onStart() {
        super.onStart();

        if (currentUser ==null)
        {
            SendUserToLoginActivity();
        }

        else
            {
                VerifyUserExistence();
            }
    }

    private void VerifyUserExistence() {

        String currentUserId = mAuthority.getCurrentUser().getUid();

        usersReference.child("Users").child(currentUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if ((dataSnapshot.child("name").exists()))
                {
                    Toast.makeText(MainActivity.this, "Welcome..", Toast.LENGTH_LONG).show();
                }
                else
                {
                    Intent settings = new Intent(MainActivity.this,SettingsActivity.class);
                    settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(settings);
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void SendUserToLoginActivity()
    {
        Intent LoginIntent = new Intent(MainActivity.this,LoginActivity.class);
        LoginIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(LoginIntent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        getMenuInflater().inflate(R.menu.options_menu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId()==R.id.main_friend_find_option)
        {

        }

        if (item.getItemId()==R.id.main_settings_option)
        {
            Intent setting=new Intent(MainActivity.this,SettingsActivity.class);
            startActivity(setting);

        }

        if (item.getItemId()==R.id.main_sign_out_option)
        {
            mAuthority.signOut();
            Intent login=new Intent(MainActivity.this,LoginActivity.class);
            startActivity(login);

        }

        if (item.getItemId()==R.id.create_main_group_option)
        {
            newGroupRequest();

        }

        return true;
    }

    private void newGroupRequest() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this,R.style.AlertDialog);
        builder.setTitle("Enter Group Name:");

        final EditText groupNameField = new EditText(MainActivity.this);
        groupNameField.setHint("Example: Shining Stars Team");
        builder.setView(groupNameField);

        builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                String groupName = groupNameField.getText().toString();

                if (TextUtils.isEmpty(groupName))
                {
                    Toast.makeText(MainActivity.this, "Group name cannot be left blank!", Toast.LENGTH_LONG).show();
                }

                else
                    {
                        CreateNewGroup(groupName);
                    }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {

                dialog.cancel();

            }
        });

        builder.show();

    }

    private void CreateNewGroup(String groupName) {

        usersReference.child("Groups").child(groupName).setValue("")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful())
                        {
                            Toast.makeText(MainActivity.this, groupName+ "The group named has been successfully created." , Toast.LENGTH_LONG).show();
                        }
                    }
                });


    }
}